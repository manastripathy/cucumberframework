package mavenprojectprototype;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HomePageHyperLinkTest {
	
	@Given("^click on targets dropdown$")
	public void click_on_targets_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^all options displayed click on All Targets$")
	public void all_options_displayed_click_on_All_Targets() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^check for All targets text on All Targets page$")
	public void check_for_All_targets_text_on_All_Targets_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^successfully landed on All Targets Page$")
	public void successfully_landed_on_All_Targets_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}


}
